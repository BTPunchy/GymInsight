import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div className="home">
      <div className="home-hero">
        <div className="hero-left">
          <h1 className="headline">
            YOUR WELLNESS JOURNEY STARTS HERE.
            <br />
            SIMPLE BOOKING POWERFUL RESULTS.
          </h1>
          <div className="cta-row">
            <Link to="/reserve" className="chip green">Reserve Room</Link>
            <span className="or">or</span>
            <a className="chip pink" href="#trainer">Booking your personal trainer</a>
          </div>
        </div>
        <div className="hero-right" aria-hidden="true" />
      </div>
    </div>
  )
}
